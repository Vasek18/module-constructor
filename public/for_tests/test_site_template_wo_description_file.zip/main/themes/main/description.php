<? if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true)
    die();
$arTemplate = Array(
    "NAME"        => GetMessage("SITE_TEMPLATE_THEME_NAME"),
    "DESCRIPTION" => GetMessage("SITE_TEMPLATE_THEME_DESCRIPTION")
);